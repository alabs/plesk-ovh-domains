<?php

require_once('lib-mbapi/include/modules/registrar/registrar.php');

$className = 'MyRegistrar';
$GLOBALS['moduleInfo'][$className] = array(
    'type'          =>      'registrar',                //module type, MUST be registrar
    'status'        =>      Registrar::STATUS_STABLE,   //module status, can be Registrar::STATUS_STABLE or Registrar::STATUS_TESTING
    'displayName'   =>      'My registrar',             //module name visible in CBM
);

class MyRegistrar extends Registrar
{
    private static $moduleCapabilities = array(
		REGISTRAR_REGISTERDOMAIN => 1,                  // identify a registrar's charge capability.
		REGISTRAR_TRANSFERDOMAIN => 1,                  // identify a registrar's transfer capability.
		REGISTRAR_RENEWDOMAIN => 1,                     // identify a registrar's renew domains capability.
		REGISTRAR_GETDOMAINEXTENDEDINFO => 1,           // identify a registrar's capability to return a domain's extended information.
        REGISTRAR_GETDOMAINEXPDATE => 1,                // identify a registrar's capability to return a domain's expiration date.
		REGISTRAR_GETDOMAINCONTACTDATA => 1,            // identify a registrar's capability to return contact info.
		REGISTRAR_SETDOMAINCONTACTDATA => 1,            // identify a registrar's capability to update contact info.
		REGISTRAR_GETDOMAINRENEWTYPEOPTIONS => 1,       // identify a registrar's capability to return a domain's renew type (manual or auto).
		REGISTRAR_SETDOMAINRENEWTYPEOPTIONS => 1,       // identify a registrar's capability to update a domain's renew type (manual or auto).
		REGISTRAR_GETDOMAINREGISTRARLOCKOPTIONS => 1,   // identify a registrar's capability to return domain registrar-lock options.
		REGISTRAR_SETDOMAINREGISTRARLOCKOPTIONS => 1,   // identify a registrar's capability to update domain registrar-lock options.
		REGISTRAR_GETDOMAINACCESSPASSWORD => 1,         // identify a registrar's capability to return a domain's access password.
		REGISTRAR_SETDOMAINACCESSPASSWORD => 1,         // identify a registrar's capability to update a domain's access password.
		REGISTRAR_LIVERENEW => 0,                       // identify a registrar's capability to do a live renewal using our system instead of the queue.
		REGISTRAR_GETTLDLIST => 1,                      //  identify a registrar's capability to return a list of TLDs.
		REGISTRAR_GETDOMAINDNS => 1,                    //  identify a registrar's capability to return a domain's DNS info.
        REGISTRAR_SETDOMAINDNS => 1,                    //  identify a registrar's capability to set a domain's DNS info.
        REGISTRAR_TLDS => array('com','net','org','biz','in','co.in','firm.in','gen.in','ind.in',
            'net.in','org.in','info','me','mobi','us','ws','es','com.es','org.es','nom.es',
            'com.mx','tv','bz','com.bz','net.bz',    //static list, is used if REGISTRAR_GETTLDLIST = 0 and function getTldList() isn't implemented
		),
	);

    /**
     * Returns the module display. This includes version number and display name.
     * @return    An array of arrays containing all the display info for the module.
     */
    public function getModuleInfo()
    {
        return $GLOBALS['moduleInfo']['MyRegistrar'];
    }

    /**
     * Construct a new MyRegistrar object. This function merely sets up capabilities after calling the
     * constructor for Registrar.
     */
    public function __construct($input)
    {
        /**
         * $input is an array of input parameters. Exact list depends on command which will be called later
         */

        // quick fix to enable IDN support across all functions
        if (isset($this->input['domainSLD']) && trim($this->input['domainSLD']) != '') {
            $this->input['domainSLD'] = $this->getPUNYCode($this->input['domainSLD']);
        }

        // set up the capabilities array
		$this->capabilities = (isset($this->capabilities) && is_array($this->capabilities))
			? array_merge($this->capabilities, self::$moduleCapabilities)
			: self::$moduleCapabilities;

        parent::Registrar($input);
     }

    // this function registers a new domain
    public function registerDomain()
    {
        /**
         * $this->input - an array of a domain regisrtation subscription attributes. Includes the following:
         * domainSLD, domainTLD, domainYears, domainNameserver1, domainNameserver2, domainNameserver3, domainNameserver4,
         * registrant info (registrantFirstName, registrantLastName, registrantOrganizationName,
         * registrantJobTitle, registrantAddress1, registrantAddress2, registrantCity, registrantState,
         * registrantPostalCode, registrantCountry, registrantEmail, registrantPhone, registrantFax etc
         */

        /**
         * Make an appropriate request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */

        /**
         * Registrar respnse processing:
         * self::ACTION_STATUS_COMPLETED - a corresponsing Business Manager event gets 'completed', the subscription gets 'active'
         * self::ACTION_STATUS_WAITING - the event still has the 'new' status, the subscription get the 'work in progress' status. The event will be executed again in 5 minutes
         * self::ACTION_STATUS_ERROR - the event gets the 'error' status, the subscription gets 'failed'
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                $this->arrayData = $registrarResponse;
                $this->commandStatus = self::ACTION_STATUS_COMPLETED;
                break;
            case "pending":
                // if the request is queued but is not still processed by the registrar
                $this->arrayData = $registrarResponse;
                $this->commandStatus = self::ACTION_STATUS_WAITING;
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
		$this->commandStatus = self::ACTION_STATUS_ERROR;
                break;
        }
        
        // the function transfer the $this->arrayData to xml and writes the data to the subscription attributes
        return $this->getRegistrarReturnXML();
    }

    /**
     * This finction is used to set the status of a domain name registration, transfer, or renewal
     * @return true/false (true if the event is completed, otherwise - false)
     */
    public function isDone()
    {
        if (self::ACTION_STATUS_WAITING == $this->commandStatus) {
            return false;
        }
        return true;
    }

    // this function performs a domain transfer
    public function transferDomain()
    {
        /**
         *  The function is similar to the registerDomain function, the difference is the request structure 
		 *	and the using of the $this->input[domainTransferKey] parameter that defines the transferability of the domain	
         */
    }

    // this function renews a  domain
    public function renewDomain()
    {
        // The function is similar to the registerDomain function, the difference is the request structure.
    }


    // this function fetches a domain contact data
    public function getDomainContactData()
    {
        // Input params ($this->input):  domainSLD, domainTLD

        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * Must be filled the following arrays from $registrarResponse:
                 * $this->arrayData['DomainData']['domainname'] - domain name
                 *
                 * $this->arrayData['RegistrantContactData']
                 * $this->arrayData['AuxBillingContactData']
                 * $this->arrayData['TechContactData']
                 * $this->arrayData['AdminContactData']
                 * $this->arrayData['BillingContactData']
                 * These arrays contain the following elements:
                 *  RegistrantContactData:
                 *  registrantAddress1, registrantAddress2, registrantCity, registrantCountry,
                 *	registrantEmailAddress, registrantFax, registrantFirstName, registrantJobTitle,
                 *	registrantLastName, registrantOrganizationName, registrantPhone, registrantPhoneExt,
                 *  registrantPostalCode, registrantStateProvince, registrantStateProvinceChoice,
                 *
                 *  AuxBillingContactData:
                 *	auxAddress1, auxAddress2, auxCity, auxCountry, auxEmailAddress, "auxFax,
                 *	auxFirstName, auxJobTitle, auxLastName, auxOrganizationName, auxPhone,
                 *	auxPhoneExt, auxPostalCode, auxStateProvince, auxStateProvinceChoice,
                 *
                 *  TechContactData:
                 *	techAddress1, techAddress2, techCity, techCountry, techEmailAddress,
                 *	techFax, techFirstName, techJobTitle, techLastName, techOrganizationName,
                 *	techPhone, techPhoneExt, techPostalCode", techStateProvince,
                 *	techStateProvinceChoice,
                 *
                 *  AdminContactData:
                 *	adminAddress1, adminAddress2, "adminCity, adminCountry, adminEmailAddress,
                 *	adminFax, adminFirstName, adminJobTitle, adminLastName, adminOrganizationName,
                 *	adminPhone, adminPhoneExt, adminPostalCode", adminStateProvince,
                 * 	adminStateProvinceChoice,
                 *
                 *  BillingContactData:
                 *	billingAddress1, billingAddress2, billingCity, billingFullCountry
                 *	billingCountry, billingEmailAddress, billingFax, billingFirstName,
                 *	billingJobTitle, billingLastName, billingOrganizationName, billingPhone,
                 *	billingPhoneExt, billingPostalCode, billingStateProvince, billingStateProvinceChoice,
                 *
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function sets a domain contact data
    public function setDomainContactData()
    {
		/**	Input params:
		 *  domainSLD, domainTLD
         *
		 *  registrantAddress1, registrantAddress2, registrantCity, registrantCountry,
		 *	registrantEmailAddress, registrantFax, registrantFirstName, registrantJobTitle,
		 *	registrantLastName, registrantOrganizationName, registrantPhone, registrantPhoneExt,
		 *  registrantPostalCode, registrantStateProvince, registrantStateProvinceChoice,
         *
		 *	auxAddress1, auxAddress2, auxCity, auxCountry, auxEmailAddress, "auxFax,
		 *	auxFirstName, auxJobTitle, auxLastName, auxOrganizationName, auxPhone,
		 *	auxPhoneExt, auxPostalCode, auxStateProvince, auxStateProvinceChoice,
         *
		 *	techAddress1, techAddress2, techCity, techCountry, techEmailAddress,
		 *	techFax, techFirstName, techJobTitle, techLastName, techOrganizationName,
		 *	techPhone, techPhoneExt, techPostalCode", techStateProvince,
		 *	techStateProvinceChoice,
         *
		 *	adminAddress1, adminAddress2, "adminCity, adminCountry, adminEmailAddress,
		 *	adminFax, adminFirstName, adminJobTitle, adminLastName, adminOrganizationName,
		 *	adminPhone, adminPhoneExt, adminPostalCode", adminStateProvince,
		 * 	adminStateProvinceChoice,
         *
		 *	billingAddress1, billingAddress2, billingCity, billingFullCountry
		 *	billingCountry, billingEmailAddress, billingFax, billingFirstName,
		 *	billingJobTitle, billingLastName, billingOrganizationName, billingPhone,
		 *	billingPhoneExt, billingPostalCode, billingStateProvince, billingStateProvinceChoice,
		 *
		 */

        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                $this->arrayData = $registrarResponse;
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function fetches a domain renewal type
    public function getDomainRenewTypeOptions()
    {
        // input params: domainSLD, domainTLD

        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * Save the respons data to the following array:
                 * $this->arrayData['domainRenewType'] 0 или 1
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function sets a domain renew type
    public function setDomainRenewTypeOptions()
    {
        /**
         * input params: domainSLD, domainTLD, domainRenewType
         *	The function is similar to the getdomainRenewTypeOptions() function, the difference is the request structure.
         */
    }


    // this function fetches a domain registrar lock status
    public function getDomainRegistrarLockOptions()
    {
        // input params: domainSLD, domainTLD

        /**
         * Make arequest to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * Save the respons data to the following arrays:
                 * $this->arrayData['domainRegistrarLock'] 1 or 0
                 * $this->arrayData['domainIsLockable'] 1 or 0
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }



    // this function sets a domain registrar lock status
    public function setDomainRegistrarLockOptions()
    {
        /**
         * input params: domainSLD, domainTLD, domainRegistrarLock
         *	The function is similar to the getDomainRegistrarLockOptions() function, the difference is the request structure.

         */
    }

    // this function fetches a domain access password
    public function getDomainAccessPassword()
    {
        // input params: domainSLD, domainTLD

        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * Save the respons data to the following array:
                 * $this->arrayData['domainAccessPassword']
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function sets a domain access password
    public function setDomainAccessPassword()
    {
        /**
         * input params: domainSLD, domainTLD, domainAccessPassword
		 *	The function is similar to the getDomainAccessPassword() function, the difference is the request structure.
         */
    }


    // this function fetches a domain renewal information
     public function getDomainExtendedInfo()
     {
        // input params: domainSLD, domainTLD

        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * Save the respons data to the following array:
                 * $this->arrayData['DomainExpDate']
                 * $this->arrayData['DomainExpTimestamp']
                 * $this->arrayData['DomainRenewMaxYears']
                 * $this->arrayData['DomainRenewDefaultYears']
                 * $this->arrayData['DomainRenewPrice']
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function fetches a domain dns info
    public function getDomainDNS()
    {
        // input params: domainSLD, domainTLD

        /**
         *	There may be two kinds on this function depending on the registrar API:		 
		 * 	1) The registrar returns only DNS server list
		 *	2) The registrar returns the domain DNS records
         */
        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                /**
                 * In the first case, the function returns:
                 * $this->arrayData['listDNS'] - DNS servers array
                 * $this->arrayData['useDNS'] - 0 or 1 - indicates using registrar DNS servers
                 * In the second case it returns:
                 * $this->arrayData['host']
                 * $this->arrayData['dnsOptions']
                 *
                 * For example:
                 * $this->arrayData['dnsOptions'] = array(
                 *      'A' => 'A',
                 *      'URL' => 'URL',
                 *      'MX' => 'MX',
                 *      'MXE' => 'MXE',
                 *      'CNAME' => 'CNAME',
                 *      'FRAME' => 'FRAME',
                 *      'TXT' => 'TXT'
                 *   );
                 *  host - an array of the records ar arrays with the following elements:type, name, address
                 * )
                 */
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }


    // this function sets a domain dns info
    public function setDomainDNS()
    {
        /** input params:
         * domainSLD, domainTLD
         * domainNameserver - DNS servers array
         * host - an array of the records ar arrays with the following elements:type, name, address
         */

        /**
         * Make a  request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         * $this->arrayData = array();
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                $this->arrayData["result"] = "TRANS_REGISTRAR_MANAGE_DNS_UPDATED";
                break;
            default:
                foreach($registrarResponse["errors"] as $error) {
                    $this->addError(blmsg("TRANS_REGISTRARERROR"), $error);
                }
                break;
        }
        return $this->getRegistrarReturnXML();
    }

    // this function populates the module configuration screen with options the user can set
    public function addDefaultConfigParams()
    {
       // below are the administrative options that can be configured for the eNom module
        /*
         * [0] = option name
         * [1] = option type (t = text, p = password, r = radio)
         * [2] = default value
         * [3] = option label
         * [4] = option description
         * [5] = array of options (in case of radio group option)
         * [6] = required field (1 or 0)
         */
        $adminOptions = array(
            array('moduleUsername',                         't',    NULL,   'USERNAME',                             NULL,                                   NULL, 1),
            array('modulePassword',                         'p',    NULL,   'PASSWORD',                             NULL,                                   NULL, 1),
            array('moduleTestMode',                         'b',    '1',    'ENABLE_TEST_MODE',                     NULL,                                   NULL, 0),
            array('moduleAllowAutoRenew',                   'r',    '0',    'ALLOW_AUTORENEW',                      'ALLOW_AUTORENEW_DESC',
                array(
                    array(
                        NULL,
                        NULL,
                        '0',
                        'TRANS_OBEY_TLD',
                        1
                    ),
                    array(
                        NULL,
                        NULL,
                        '1',
                        'TRANS_REGISTRAR_AUTORENEW_OPTION',
                        2
                    ),
                    array(
                        NULL,
                        NULL,
                        '2',
                        'TRANS_MODERNBILL_RENEW_OPTION',
                        3
                    ),
                ), 0
            ),
            array('moduleUseCustomNameserver',              'b',    '0',    'USE_CUSTOM_NAMESERVER',                'USE_CUSTOM_NAMESERVER_DESC',           NULL, 0),
            array('moduleAllowChangeDNS',                   'b',    '0',    'ALLOW_CHANGE_DNS',                     'ALLOW_CHANGE_DNS_DESC',                NULL, 0),
            array('moduleAllowChangeContactInfo',           'b',    '1',    'ALLOW_CHANGE_CONTACT_INFO',            'ALLOW_CHANGE_CONTACT_INFO_DESC',       NULL, 0),
            array('moduleAllowChangeRegistrarLock',         'b',    '0',    'ALLOW_CHANGE_REGISTRAR_LOCK',          'ALLOW_CHANGE_REGISTRAR_LOCK_DESC',     NULL, 0),
            array('moduleAllowChangeAutorenew',             'b',    '0',    'ALLOW_CHANGE_AUTORENEW',               'ALLOW_CHANGE_AUTORENEW_DESC',          NULL, 0),
            array('moduleAllowChangeUpdateDomainPassword',  'b',    '0',    'ALLOW_CHANGE_UPDATE_DOMAIN_PASSWORD',  'ALLOW_CHANGE_UPDATE_DOMAIN_PASSWORD_DESC',  NULL, 0),
        );

        // generate the necessary fields so that Admin/Tech/AuxBilling contacts can be filled
        foreach($this->contactTypes as $contactType) {
            if ($contactType != 'Registrant') {
                foreach($this->contactParams as $contactParam) {
					switch($contactType) {
						case 'Admin' : $groupTransKey = 'TRANS_ADMINISTRATIVE_CONTACT'; break;
						case 'Tech' : $groupTransKey = 'TRANS_TECHNICAL_CONTACT'; break;
						case 'AuxBilling' : $groupTransKey = 'TRANS_BILLING_CONTACT'; break;
						default: $groupTransKey = 'TRANS_REGISTRAR_'.strtoupper($contactType).'_CONTACT';
					}
					$contactConfig[] = array(
					NULL,
					NULL,
					$contactType.$contactParam,
					'',
					$groupTransKey,
					'TRANS_REGISTRAR_'.strtoupper($contactType).'_'.strtoupper(str_replace(' ','_',variableToHuman($contactParam))),
					'',
					't',
					0,
					$i++,
					0,
					NULL
					);
                }
            }
        }

        // generate the nameserver fields that can be filled out in the
        $nameServerConfig = array(
            array(NULL,NULL,'domainNameserver1','','TRANS_REGISTRAR_NS','TRANS_REGISTRAR_NS1','','t',0,$i++,0,array()),
            array(NULL,NULL,'domainNameserver2','','TRANS_REGISTRAR_NS','TRANS_REGISTRAR_NS2','','t',0,$i++,0,array()),
            array(NULL,NULL,'domainNameserver3','','TRANS_REGISTRAR_NS','TRANS_REGISTRAR_NS3','','t',0,$i++,0,array()),
            array(NULL,NULL,'domainNameserver4','','TRANS_REGISTRAR_NS','TRANS_REGISTRAR_NS4','','t',0,$i++,0,array())
        );


        // create the master array which we'll return containing all configuration parameters
        $defaultConfigParams = array_merge($moduleConfig, $contactConfig);
        $defaultConfigParams = array_merge($defaultConfigParams, $nameServerConfig);

        // return the master array containing all configuration parameters
        return $defaultConfigParams;

    }

    // get list of TDLs that your registrar supports
    public function getTLDList()
    {
        /**
         * Make a request to registrar (use Curl, Soap etc)
         * using $this->UID and $this->PW ('moduleUsername','modulePassword')
         * $registrarResponse = callToRegistrar(prepareRequest($this->input));
         * initialize the arrayData variable (what params function will returns)
         */
        switch ($registrarResponse["returnCode"]) {
            case "success":
                // must be exactly this code
                /**
                 * $registrarResponse["tlds"] - an array of supported TLDs
                 */
                $this->capabilities[REGISTRAR_TLDS] = $registrarResponse["tlds"];
                return $this->capabilities[REGISTRAR_TLDS];
            default:
                return array();
        }
    }

    /** Get form field descriptor for domain contact information (filled in Store and in Admin CP before domain buying)
     * param string $action - (register, transfer)
     * param string $domain_sld
     * param string $domain_tld
     */
    public function getRegistrantParams($action, $domain_sld, $domain_tld, ClientContact $contact = NULL, $withTLDParams = false)
	{
        // getting standart registrant contact form descriptor
		$registrantParams = parent::getRegistrantParams($action, $domain_sld, $domain_tld, $contact, $withTLDParams);

        /**
         * You can add more fields to te list
         *
         * $registrantParams = array(array(
         *      "title" => "",
         *      "description" => "",
         *      "inputs" => $inputs,
         *  ));
         *  , where the $inputs has the following structure:
         *  $inputs = array (
         *     array(
         *          "id"		=> "<domain_fieldID>",
         *          "type"		=> "t",
         *          "title"		=> blmsg("<APPROPRIATE LOCALE KEY NAME>"),
         *          "required"	=> 0,  - 1 or 0
         *          "default"	=> "", - default value
         *     ),
         *  );
         *  Possible field types:
         * 	    'b' => 'checkbox',
         *      's' => 'select',
         *      't' => 'text',
         *      'r' => 'radio',
         *      'c' => 'checkbox',
         *      'x' => 'html',
         *      'a' => 'textarea',
         *      'p' => 'password',
         */

		return $registrantParams;
	}
}

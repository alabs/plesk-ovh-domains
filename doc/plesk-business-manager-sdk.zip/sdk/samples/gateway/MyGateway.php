<?php

require_once('lib-mbapi/include/modules/gateway/gateway.php');

$className = 'MyGateway';

$GLOBALS['moduleInfo'][$className] = array(
	'type' => 'gateway',
	'status' => PaymentGateway::STATUS_STABLE,
	'version' => '1.0.0',
	'gatewaytype' => PaymentGateway:: TYPE_PRIMARY,
	'displayName' => $className,
	'author' => 'Parallels',
	'capabilities' => array(
		GATEWAY_CHARGE,
		GATEWAY_AUTHORIZE,
		GATEWAY_PRIOR_AUTH_CHARGE,
		GATEWAY_REFUND,
		GATEWAY_VOID,
		GATEWAY_IPV6_COMPLIANCE,
	),
	'countryCodes' => array('US', 'CA'),
);

class MyGateway extends Gateway
{
	public function __construct($input)
	{
		parent::__construct($input);
		// �
	}
	
	public function getModuleInfo()
	{
		return $GLOBALS['moduleInfo'][ 'MyGateway'];
	}
	
	public function addDefaultConfigParams ()
	{
		return array(
			array(NULL, NULL, "login", "", "", "TRANS_MYGATEWAY_LOGIN",
				"TRANS_MYGATEWAY_LOGIN_DESC", "t", 1, 1, 0, NULL),
			array(NULL, NULL, "password", "", "", "TRANS_MYGATEWAY_PASSWORD",
				"TRANS_MYGATEWAY_PASSWORD_DESC", "p", 1, 2, 0, NULL),
			array(NULL, NULL, "mode", "simulation", "", "TRANS_GATEWAY_MODE",
				"TRANS_GATEWAY_MODE_DESC", "s", 1, 3, 0, array(
					array(NULL, NULL, "simulation", "TRANS_SIMULATION", 1),
					array(NULL, NULL, "test", "TRANS_TEST", 2),
					array(NULL, NULL, "live", "TRANS_LIVE", 3),
			)),
			array(NULL, NULL, "language", "en", "", "TRANS_DISPLAY_LANGUAGE",
				"TRANS_DISPLAY_LANGUAGE_DESC", "r", 1, 3, 0, array(
					array(NULL, NULL, "en", "TRANS_ENGLISH", 0),
					array(NULL, NULL, "sp", "TRANS_SPANISH", 1),
			)),
			array(NULL, NULL, "orderDescription", "", "", "TRANS_MYGATEWAY_ORDER_DESCRIPTION",
				"TRANS_MYGATEWAY_ORDER_DESCRIPTION_DESC", "a", 0, 4, 0, NULL),
			array(NULL, NULL, "card_accept_0", "1", "TRANS_CREDITCARD_SETTINGS", "TRANS_ACCEPT_VISA",
				"TRANS_ACCEPT_VISA_DESC", "b", 1, 5, 0, NULL),
			array(NULL, NULL, "card_accept_1", "1", "TRANS_CREDITCARD_SETTINGS", 
				"TRANS_ACCEPT_MASTERCARD", "TRANS_ACCEPT_MASTERCARD_DESC", "b", 1, 6, 0, NULL),
			array(NULL, NULL, "card_accept_2", "1", "TRANS_CREDITCARD_SETTINGS", "TRANS_ACCEPT_AMEX",
				"TRANS_ACCEPT_AMEX_DESC", "b", 1, 7, 0, NULL),
			array(NULL, NULL, "card_accept_3", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_DISCOVER", "TRANS_ACCEPT_DISCOVER_DESC", "b", 1, 8, 0, NULL),
			array(NULL, NULL, "card_accept_4", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_JCB", "TRANS_ACCEPT_JCB_DESC", "b", 1, 9, 0, NULL),
			array(NULL, NULL, "card_accept_6", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_DINERS", "TRANS_ACCEPT_DINERS_DESC", "b", 1, 10, 0, NULL),
			array(NULL, NULL, "card_accept_7", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_SOLO", "TRANS_ACCEPT_SOLO_DESC", "b", 1, 11, 0, NULL),
			array(NULL, NULL, "card_accept_8", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_MAESTRO", "TRANS_ACCEPT_MAESTRO_DESC", "b", 1, 12, 0, NULL),
			array(NULL, NULL, "card_accept_9", "1", "TRANS_CREDITCARD_SETTINGS",
				"TRANS_ACCEPT_DELTA", "TRANS_ACCEPT_DELTA_DESC", "b", 1, 13, 0, NULL),
			array(NULL, NULL, "card_accept_11", "1", "TRANS_CREDITCARD_SETTINGS", 
				"TRANS_ACCEPT_ELECTRON", "TRANS_ACCEPT_ELECTRON_DESC", "b", 1, 14, 0, NULL),
		);
	}

public function execute()
{
	switch ($this->params['subCommand'][0]) {
		case 'charge':
			// call gateway to perform charge action
			// ...
			// $this->status = GATEWAY_SUCCESS;    // assign operation status, possible statuses are
			//                                                                      // GATEWAY_SUCCESS, GATEWAY_DECLINED,
			//                                                                      // GATEWAY_FAILURE
			// $this->message = ...                        // assign message returned by gateway or you own message
			// if (GATEWAY_SUCCESS == $this->status) {
			//     $this->authorizationCode = ...  // assign authorization code returned by gateway
			//     $this->transactionID = ...           // assign transaction identifier rAUTHOeturned by gateway
			//     $this->AVSCode = ...                   // assign AVS code returned by gateway
			// }
			break;
		case 'auth':
			// call gateway to perform authorization action
			// ...
			// $this->status = GATEWAY_SUCCESS;    // assign operation status, possible statuses are
			//                                                                      // GATEWAY_SUCCESS, GATEWAY_DECLINED,
			//                                                                      // GATEWAY_FAILURE
			// $this->message = ...                        // assign message returned by gateway or you own message
			// if (GATEWAY_SUCCESS == $this->status) {
			//     $this->authorizationCode = ...  // assign authorization code returned by gateway
			//     $this->transactionID = ...           // assign transaction identifier returned by gateway
			//     $this->AVSCode = ...                   // assign AVS code returned by gateway
			// }
			break;
		case 'finalize':
			// call gateway to perform capture action
			// ...
			// $this->status = GATEWAY_SUCCESS;    // assign operation status, possible statuses are
			//                                                                      // GATEWAY_SUCCESS, GATEWAY_DECLINED,
			//                                                                      // GATEWAY_FAILURE
			// $this->message = ...                        // assign message returned by gateway or you own message
			break;
		case 'refund':
			// call gateway to perform refund action
			// ...
			// $this->status = GATEWAY_SUCCESS;    // assign operation status, possible statuses are
			//                                                                      // GATEWAY_SUCCESS, GATEWAY_DECLINED,
			//                                                                      // GATEWAY_FAILURE
			// $this->message = ...                        // assign message returned by gateway or you own message
			break;
		case 'void':
			// call gateway to perform void action
			// ...
			// $this->status = GATEWAY_SUCCESS;    // assign operation status, possible statuses are
			//                                                                      // GATEWAY_SUCCESS, GATEWAY_DECLINED,
			//                                                                      // GATEWAY_FAILURE
			// $this->message = ...                        // assign message returned by gateway or you own message
			break;
		default:
			$this->status = GATEWAY_ERROR;
			$this->message = 'Invalid Gateway Action Requested';
	}

	$result = array(
		'status' => $this->status,
		'statusName' => getAPIStatusName('transactions', $this->status),
		'statusMessage' => getStatusName('transactions', $this->status),
		'authorizationCode' => $this->authorizationCode,
		'transactionID' => $this->transactionID,
		'AVSCode' => $this->AVSCode,
		'message' => $this->message,
	);

	$this->hasExecuted = 1;
	return $this->createOutputXML($result);
}

}

<?php
require_once mb_path("/lib-mbapi/include/modules/sslmodule/sslmodule.php");

class ExampleSSL extends SSLModule
{
	
	public function getModuleInfo()
	{
		return array(
			"type"			=> "sslmodule",
			"version"		=> "1.0.0",
			"displayName"	=> "ExampleSSL",
			"author"		=> "Parallels",
		);
	}

	public function __construct($input)
	{
		parent::__construct($input);
		$this->capabilities = array(
			SSLModule::CAPABILITY_USER_PARAMS
		);
	}
	
	public function getCertificates()
	{
		return array(
			'RapidSSL-RapidSSL' => false,
			'Comodo-Instant' => false
		);
	}
	
	public function getPeriod($certificate)
	{
		switch ($certificate) {
			case 'RapidSSL-RapidSSL':
				return 1;
			case 'Comodo-Instant':
				return 2;
			default:
				return 0;
		}
	}
	
	public function getCertificateAttributeName()
	{
		return 'examplessl_certificate';
	}
	
	public function getPeriodAttributeName()
	{
		return 'examplessl_period';
	}

	public function cryptedConfigParams()
	{
		return array("password");
	}
	
	/**
	 * This defines how the module is configured in the application.
	 * This section should contain any piece of data needed to connect with the cert provider.
	 * These will be used to build a form the admin will use to configure their account
	 * settings given to them by the cert provider.
	 * 
	 * Поддерживаются следующие типы полей:
	 * 
	 * CIT_TEXT			text
	 * CIT_TEXT_AREA	textarea
	 * CIT_RADIO		radio group
	 * CIT_SELECT		drop down list
	 * CIT_BOOL			true/false radio group
	 * CIT_PASSWORD		password
	 * 
	 * @param	$ui_form	объект формы, в которую слеудет добавить
	 * 						необходимые поля ввода
	 * @param	$config		ассоциативный массив текущих параметров конфигурации провайдера,
	 * 						пустой в случае создания нового провайдера
	 */
	protected function drawConfigParams(UIForm $form, array $config)
	{
		$form->addInputPanel(
			$panel = UIFactory()->InputPanel(blmsg("TRANS_SSL_PLUGIN_CONFIG"))
		);
		$panel->addInputControl(UIFactory()->InputConfig(array(
			"id"		=> "url",
			"type"		=> SSLModule::CIT_TEXT,
			"default"	=> isset($config["url"]) ? $config["url"] : "http://example-ssl.net",
			"required"	=> true,
			"title"		=> "TRANS_SSL_PLUGIN_CONFIG_EXAMPLE_SSL_URL",
		)));
		$panel->addInputControl(UIFactory()->InputConfig(array(
			"id"		=> "login",
			"type"		=> SSLModule::CIT_TEXT,
			"default"	=> isset($config["login"]) ? $config["login"] : "",
			"required"	=> true,
			"title"		=> "TRANS_SSL_PLUGIN_CONFIG_EXAMPLE_SSL_LOGIN",
		)));
		$panel->addInputControl(UIFactory()->InputConfig(array(
			"id"		=> "password",
			"type"		=> SSLModule::CIT_PASSWORD,
			"default"	=> isset($config["password"]) ? $config["password"] : "",
			"required"	=> true,
			"title"		=> "TRANS_SSL_PLUGIN_CONFIG_EXAMPLE_SSL_PASSWORD",
		)));
	}
	
	
	protected function getCollectedConfigParams(UIForm $form, array $config)
	{
		$values = array();
		$form->storeValues($values);
		return array(
			"url"		=> $values["url"],
			"login"		=> $values["login"],
			"password"	=> $values["password"]
		);
	}

	protected function drawUserParams(UIForm $form, array $config, array $attributes)
	{
		$form->addInputPanel(
			$panel = UIFactory()->InputPanel(blmsg("TRANS_SSL_PLUGIN_ADDITIONAL_DATA"))
		);
		$emails = $this->getApproverEmails($config, $attributes["examplessl_order_id"]);
		$panel->addInputControl(UIFactory()->InputConfig(array(
			"id"		=> "ApproverEmail",
			"type"		=> SSLModule::CIT_SELECT,
			"default"	=> isset($attributes["ApproverEmail"]) ? $attributes["ApproverEmail"] : "",
			"required"	=> true,
			"title"		=> "TRANS_SSL_PLUGIN_CONFIG_EXAMPLE_SSL_APPROVER_EMAIL",
			"items"		=> $emails
		)));
	}
	
	protected function getCollectedUserParamsFromUIForm(UIForm $form, array $config, array $attributes)
	{
		$values = array();
		$form->storeValues($values);
		return array('ApproverEmail' => $values["ApproverEmail"]);
	}
	
	public function getParamGroupsMap()
	{
		return array("additional_data" => "TRANS_SSL_PLUGIN_ADDITIONAL_DATA"); 
	}
	
	protected function getUserParamsDescriptor(array $config, array $attributes)
	{
		$emails = $this->getApproverEmails($config, $attributes["examplessl_order_id"]);
		return array(
			"additional_data" => array(
				array(
					"id"		=> "ApproverEmail",
					"type"		=> SSLModule::CIT_SELECT,
					"title"		=> blmsg("TRANS_SSL_PLUGIN_CONFIG_EXAMPLE_SSL_APPROVER_EMAIL"),
					"required"	=> true,
					"default"	=> $attributes["ApproverEmail"],
					"items"		=> $emails
				)
			)
		);
	}
	
	protected function getCollectedUserParamsFromArray(array $config, array $attributes, array $values)
	{
		return $values;
	}
	
	protected function drawProductParams(UIForm $ui_form, array $config, array $product)
	{
	}

	protected function getCollectedProductParams(UIForm $ui_form, array $config, array $product)
	{
	}
	
	protected function pluginCheckAttributes(array $config, array $attributes, $action)
	{
		$errors = array();
		switch ($action) {
			case "add":
				if (!isset($attributes["CSR"])) {
					$errors["CSR"] = "No CSR defined";
				} elseif (false === openssl_csr_get_subject($attributes["CSR"])) {
					$errors["CSR"] = "Unknown CSR key";
				}
				$orderId = isset($attributes["examplessl_order_id"]) ? $attributes["examplessl_order_id"] : false;
				if ($orderId && !isset($attributes["ApproverEmail"])) {
					$errors["ApproverEmail"] = "No approver's EMail defined";
				}
		}
		return $errors;
	}

	protected function pluginAdd(array $config, array $attributes)
	{
		try {
			if (!isset($attributes["examplessl_order_id"])) {
				$orderId = $this->createOrder(
					$config,
					$attributes["examplessl_certificate"],
					$attributes["examplessl_period"]
				);
				return array(
					"status" => SSLModule::ACTION_STATUS_PENDING,
					"status_reason" => "TRANS_ENOMSSL_STATUS_REASON__WAITING_FOR_ADDITIONAL_DATA",
					"data" => array(
						"examplessl_order_id" => $orderId
					)
				);
			} else if (!isset($attributes["examplessl_configured"])) {
				$orderId = $attributes["examplessl_order_id"];
				$this->uploadAdditionalData(
					$config,
					$orderId,
					$attributes["ApproverEmail"]
				);
				return array(
					"status" => SSLModule::ACTION_STATUS_PENDING,
					"status_reason" => "TRANS_ENOMSSL_STATUS_REASON__WAITING_FOR_COMPLETE_PURCHASE",
					"data" => array(
						"examplessl_configured" => 1
					)
				);
			} else {
				if ($certificate = $this->downloadCertificate($config, $orderId)) {
					return array(
						"status" => SSLModule::ACTION_STATUS_COMPLETED,
						"data" => array(
							"CSR" => $attributes["CSR"],
							"SSLCertificate" => $certificate
						)
					);
				} else {
					return array(
						"status" => SSLModule::ACTION_STATUS_PENDING,
						"status_reason" => "TRANS_ENOMSSL_STATUS_REASON__WAITING_FOR_COMPLETE_PURCHASE"
					);
				}
			}
		} catch (Exception $exception) {
			$this->pushErrorToAdminsToDo($exception->getMessage());
			return array(
				"status" => SSLModule::ACTION_STATUS_ERROR,
				"error" => $exception->getMessage()
			);
		}
	}

	protected function pluginRenew(array $config, array $attributes)
	{
		$data = array();
		if (isset($attributes["SSLCertificate"])) {
			$data["examplessl_order_id"] = $attributes["examplessl_order_id"] = null;
			$data["examplessl_configured"] = $attributes["examplessl_configured"] = null;
			$data["SSLCertificate"] = $attributes["SSLCertificate"] = null;
			$csrData = $this->generateCSR();
			$data["CSR"] = $attributes["CSR"] = $csrData["csr"];
			$data["PVT"] = $attributes["PVT"] = $csrData["pvt"];
		}
		$response = $this->pluginAdd($config, $attributes);
		$response["data"] = isset($response["data"]) ? array_merge($data, $response["data"]) : $data;
		return $response;
	}

	protected function pluginGetIssuedCert(array $config, array $attributes)
	{
	}

	protected function pluginGetCSR(array $config, array $attributes)
	{
	}
	
	protected function pluginDelete(array $config, array $attributes)
	{
	}

	public static function webServerTypes($attributes)
	{
		return array(
			28,
			array(
				"1" => "Apache + MOD SSL",
				"3" => "Apache + SSLeay",
				"28" => "Plesk"
			)
		);
	}
	
	private function createOrder($config, $certificate, $period) {
		return $config['login'] . '-' . $certificate . '-' . $period . '-' . time();
	}
	
	private function uploadAdditionalData($config, $orderId, $approverEmail) {
		return true;
	}
	
	private function downloadCertificate($config, $orderId) {
		return 'certificate-body';
	}
	
	private function getApproverEmails($config, $orderId) {
		return array(
			array("admin@example.com", "admin@example.com"),
			array("root@example.com", "root@example.com")
		);
	}
	
}
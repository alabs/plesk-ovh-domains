<?php
require_once mb_path("/lib-mbapi/include/modules/sslmodule/sslmodule.php");

class ExampleSSL extends SSLModule
{
	
	public function getModuleInfo()
	{
		return array(
			"type"			=> "sslmodule",
			"version"		=> "1.0.0",
			"displayName"	=> "ssl_plugin_template",
			"author"		=> "Parallels",
		);
	}

	public function __construct($input)
	{
		parent::__construct($input);
		$this->capabilities = array(
			SSLModule::CAPABILITY_USER_PARAMS
		);
	}
	
	public function getCertificates()
	{
		return array();
	}
	
	public function getPeriod($certificate)
	{
		switch ($certificate) {
			default:
				return 0;
		}
	}
	
	public function getCertificateAttributeName()
	{
		return 'add_plan_property_name';
	}
	
	public function getPeriodAttributeName()
	{
		return 'add_another_plan_property_name';
	}

	public function cryptedConfigParams()
	{
		return array();
	}
	
	/**
	 * This defines how the module is configured in the application.
	 * This section should contain any piece of data needed to connect with the cert provider.
	 * These will be used to build a form the admin will use to configure their account
	 * settings given to them by the cert provider.
	 * 
	 * Поддерживаются следующие типы полей:
	 * 
	 * CIT_TEXT			text
	 * CIT_TEXT_AREA	textarea
	 * CIT_RADIO		radio group
	 * CIT_SELECT		drop down list
	 * CIT_BOOL			true/false radio group
	 * CIT_PASSWORD		password
	 * 
	 * @param	$ui_form	объект формы, в которую слеудет добавить
	 * 						необходимые поля ввода
	 * @param	$config		ассоциативный массив текущих параметров конфигурации провайдера,
	 * 						пустой в случае создания нового провайдера
	 */
	protected function drawConfigParams(UIForm $form, array $config)
	{
		// Call $form->addInputPanel
	}
	
	
	protected function getCollectedConfigParams(UIForm $form, array $config)
	{
		return array();
	}

	protected function drawUserParams(UIForm $form, array $config, array $attributes)
	{
		// Call $form->addInputPanel
	}
	
	protected function getCollectedUserParamsFromUIForm(UIForm $form, array $config, array $attributes)
	{
		$values = array();
		$form->storeValues($values);
		return array();
	}
	
	public function getParamGroupsMap()
	{
		return array(); 
	}
	
	protected function getUserParamsDescriptor(array $config, array $attributes)
	{
		return array();
	}
	
	protected function getCollectedUserParamsFromArray(array $config, array $attributes, array $values)
	{
		return $values;
	}
	
	protected function drawProductParams(UIForm $ui_form, array $config, array $product)
	{
	}

	protected function getCollectedProductParams(UIForm $ui_form, array $config, array $product)
	{
	}
	
	protected function pluginCheckAttributes(array $config, array $attributes, $action)
	{
		return array();
	}

	protected function pluginAdd(array $config, array $attributes)
	{
	
	return array(
						"status" => SSLModule::ACTION_STATUS_COMPLETED,
						"data" => array(
							"CSR" => $attributes["CSR"],
							"SSLCertificate" => "certificate body"
						)
					);
	}

	protected function pluginRenew(array $config, array $attributes)
	{
	}

	protected function pluginGetIssuedCert(array $config, array $attributes)
	{
	}

	protected function pluginGetCSR(array $config, array $attributes)
	{
	}
	
	protected function pluginDelete(array $config, array $attributes)
	{
	}

	public static function webServerTypes($attributes)
	{
		return array(
			7,
			array(
				"7" => "Plesk",
			)
		);
	}
		
	
}